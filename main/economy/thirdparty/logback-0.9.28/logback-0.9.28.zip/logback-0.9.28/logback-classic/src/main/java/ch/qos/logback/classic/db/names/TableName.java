package ch.qos.logback.classic.db.names;

/**
 * @author Tomasz Nurkiewicz
 * @since 0.9.19
 */
public enum TableName {

  LOGGING_EVENT,
  LOGGING_EVENT_PROPERTY,
  LOGGING_EVENT_EXCEPTION

}
